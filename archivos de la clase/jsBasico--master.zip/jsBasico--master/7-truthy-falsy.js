// Truthy y Falsy 

// Son valores que son verdaderos o falsos 

// Falsy (False)

"" // un string vacío 
0 -0
null
NaN
false
undefined

//Truthy (true)

"hola"
30
{a:1}
[1,3]
true
function a(){}
más 

// Para que podemos utilizar esto, para generar condiciones segun el valor que demos. 

if(InputEvent.value) {
    ...
}
