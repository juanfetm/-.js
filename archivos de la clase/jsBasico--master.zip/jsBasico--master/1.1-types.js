Number 
Boolean
String
undefined
null
Object
Symbol

// typeof es un tipo de operador unitario "Unary operator" que trabaja con 1 operando (variable)

var nombre; 

typeof 30 
typeof true
typeof "Diego" 
typeof nombre 
typeof null
typeof {}
typeof []

