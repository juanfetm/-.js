
// Binary operators, y esto es porque significa que están 2 operandos involucrado 

// de operación 

3 + 2
50 - 10
10 * 3
20 / 2

'Diego ' + 'De Granda'

// Unary operator, aquí es porque hay solo 1 operando involucrado 

// Lógicos 

!false // operador not (no)

// Asignación 

var a = 1; 

// comparación 

3 == '3' // es igual

3 === '3' // es estrictamente igual 

5 < 3, 5 <= 3, 5 > 3, 5 >= 3 // menor, menor o igual, mayo, mayor o igual 

a && b // operador and (y), este operador genera una valicación siempe y cuando ambas variables sean verdad, "var 1 y var 2"

true || false // operador or (o), este operador genera una validacion siempre y cuando cuaquier de as variables sea verdad, "var 1 o var 2"


/* ================================================================ */ 

// Operador que solo se pueden utilizar con variables 

var edad = 40;

edad++;  // operador de incremento por 1
edad += 2; 

edad;

